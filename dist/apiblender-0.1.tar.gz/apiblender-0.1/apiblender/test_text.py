import main

blender = main.Blender()

blender.load_server('google_plus')
blender.load_interaction('activities_search')
blender.set_url_params({'query': 'hollande'})
print blender.blend()

blender.load_server('flickr')
blender.load_interaction('photos_search')
blender.set_url_params({'tags': 'hollande'})
print blender.blend()

blender.load_server('youtube')
blender.load_interaction('search')
blender.set_url_params({'q': 'hollande'})
print blender.blend()
blender.load_server('twitter-generic')
blender.load_interaction('followers')
blender.set_url_params({'screen_name': 'netiru'})
print blender.blend()

blender.load_server('twitter-search')
blender.load_interaction('search')
blender.set_url_params({'q': 'hollande'})
print blender.blend()



